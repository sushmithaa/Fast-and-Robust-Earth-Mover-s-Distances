% This demo efficiently computes the emd_hat between two 1d

clc; close all; clear all;
rand('state',sum(100*clock)); 

N= 1000;
THRESHOLD= 3; %threshold value
extra_mass_penalty= -1;
flowType= 3;

P= rand(N,1);
Q= rand(N,1);

D= ones(N,N).*THRESHOLD;
for i=1:N
    for j=max([1 i-THRESHOLD+1]):min([N i+THRESHOLD-1])
        D(i,j)= abs(i-j); 
    end
end

% The demo calls emd_hat_mex and emd_hat_gd_metric_mex
demo_FastEMD_compute(P,Q,D,extra_mass_penalty,flowType);
