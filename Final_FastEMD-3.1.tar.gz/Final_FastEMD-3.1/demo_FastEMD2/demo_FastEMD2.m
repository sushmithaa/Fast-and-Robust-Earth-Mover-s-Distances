% This demo efficiently computes emd_hat between two random SIFTs

clc; close all; clear all;
rand('state',sum(100*clock));

XNBP= 4; % SIFT's X-dimension
YNBP= 4; % SIFT's Y-dimension
NBO= 16; % SIFT's Orientation-dimension
N= XNBP*YNBP*NBO;
thresh= 2;       %threshold value
extra_mass_penalty= -1; % Default of maximum distance
flowType= 3; % Regular flows

% SIFT ground distance matrix computation.

D= zeros(N,N);
i= 1;
for y1=1:YNBP
    for x1=1:XNBP
        for nbo1=1:NBO
            
            j= 1;
            for y2=1:YNBP
                for x2=1:XNBP
                    for nbo2=1:NBO
                        D(i,j)= (sqrt((y1-y2)^2 + (x1-x2)^2) + min( [abs(nbo1-nbo2) NBO-abs(nbo1-nbo2)] ));
                        j=j+1;
                    end
                end
            end
            i= i+1;
            
        end
    end
end
maxDist= max(D(:));
D= min(D,thresh);

    
P= rand(N,1);
Q= rand(N,1);

% The demo includes several ways to call emd_hat_mex and emd_hat_gd_metric_mex
demo_FastEMD_compute(P,Q,D,extra_mass_penalty,flowType);

